opencv_version = "3.4.13.47"
contrib = True
headless = False
ci_build = True